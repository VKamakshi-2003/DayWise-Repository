import mongoose from "mongoose";

async function main() {
  // connect to MongoDB
  await mongoose.connect("mongodb://127.0.0.1:27017/bookstore");
  console.log("✅ MongoDB connected");

  // define schema & model
  const bookSchema = new mongoose.Schema({
    title: String,
    author: String,
    price: Number
  });
  const Book = mongoose.model("Book", bookSchema);

  // add a book
  await Book.create({ title: "Node.js Basics", author: "Chandana", price: 499 });

  // list all books
  const books = await Book.find();
  console.log("📖 All Books:", books);

  // find book by title
  const found = await Book.findOne({ title: "Node.js Basics" });
  console.log("🔍 Found:", found);

  // update price
  const updated = await Book.findOneAndUpdate(
    { title: "Node.js Basics" },
    { price: 599 },
    { new: true }
  );
  console.log("💰 Updated:", updated);

  await mongoose.disconnect();
}

main().catch(err => console.error("❌ Error:", err));
