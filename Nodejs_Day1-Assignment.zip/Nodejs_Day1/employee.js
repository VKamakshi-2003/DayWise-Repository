import mysql from "mysql2/promise";

async function main() {
  // connect to MySQL
  const conn = await mysql.createConnection({
    host: "localhost",
    user: "root",        // change if needed
    password: "pass@word",// change if needed
    database: "employeeDB"
  });
  console.log("✅ MySQL connected");

  // add employee
  await conn.execute(
    "INSERT INTO employees (name, email, department) VALUES (?, ?, ?)",
    ["Chandana", "chandana@example.com", "IT"]
  );

  // list employees
  const [rows] = await conn.execute("SELECT * FROM employees");
  console.log("📋 Employees:", rows);

  // update employee
  await conn.execute(
    "UPDATE employees SET department=? WHERE name=?",
    ["HR", "Chandana"]
  );

  // delete employee
  await conn.execute("DELETE FROM employees WHERE name=?", ["Chandana"]);

  await conn.end();
  console.log("🔌 Connection closed");
}

main().catch(err => console.error("❌ Error:", err));
