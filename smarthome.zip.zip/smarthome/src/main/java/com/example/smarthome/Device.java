package com.example.smarthome;

public class Device {

}
