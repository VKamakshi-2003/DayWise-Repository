package com.example.smarthome;

public class AppConfig {

}
