package com.example.smarthome;

public class AutomationService {

}
